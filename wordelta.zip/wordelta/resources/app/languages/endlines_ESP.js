export const ESP_win_1 = [
    " A!?"
];

export const ESP_win_2_3 = [
    "QUE SUERTE!!!",
    "INESPERADO!!!",
    "AMIX!?"
];

export const ESP_win_4_5 = [
    "MUY BIEN!",
    "BIEN HECHO!",
    "BUEN TRABAJO!",
    "BUENA ESA!",
    "FELICIDADES!",
    "YAY!"
];

export const ESP_win_6 = [
    "#BENDECIDX",
    "SALVADA...",
    "QUE SUERTE!",
    "BUENA ELECCION!",
    ":GAFAS_DE_SOL:",
    "BUENO BUENO..."
];

export const ESP_lose = [
    "PERDON AMIX...",
    "NO TE DESANIMES!",
    "A LA PROXIMA QUEDA!",
    "ANIMOS MI REINA / REY!",
    "FUE UN BUEN INTENTO...",
    "#ASIESLAVIDA",
    "NO TE RINDAS!!"
];

export const ESP_check = [
    "QUE SIGNIFICA!?",
    "LA PALABRA!!!",
    "REVISA QUE ES!",
    "SI, SI EXISTE...",
    "SI LE SABES?",
    "Y SU DEFINICION ES...",
    "Y SIGNIFICA..."
];