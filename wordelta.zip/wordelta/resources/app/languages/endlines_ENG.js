export const ENG_win_1 = [
    " A!?"
];

export const ENG_win_2_3 = [
    "HOW LUCKY!!!",
    "UNEXPECTED!!!",
    "FRIEND!?"
];

export const ENG_win_4_5 = [
    "VERY WELL!",
    "WELL DONE!",
    "GOOD JOB!",
    "NICE ONE!",
    "CONGRALUTATIONS!",
    "YAY!"
];

export const ENG_win_6 = [
    "#BLESSED",
    "SAVED...",
    "LUCKY!",
    "SMART CHOICE!",
    ":SUNGLASSES:",
    "WELL WELL..."
];

export const ENG_lose = [
    "SORRY, FRIEND...",
    "KEEP YOUR HEAD UP!",
    "YOU'LL GET IT NEXT TIME!",
    "DON'T WORRY QUEEN / KING!",
    "IT WAS A GOOD TRY...",
    "#LIFE",
    "NEVER SURRENDER!!"
];

export const ENG_check = [
    "WHAT IS THIS WORD!?",
    "THE WORD!!!",
    "CHECK THE WORD!",
    "YES, IT EXISTS...",
    "WANNA KNOW WHAT IT IS?",
    "AND ITS DEFINITION IS...",
    "WHAT DOES IT MEAN..."
];